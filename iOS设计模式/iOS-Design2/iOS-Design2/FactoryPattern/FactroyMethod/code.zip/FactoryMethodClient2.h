//
//  FactoryMethodClient2.h
//  iOS-Design2
//
//  Created by 神州第一坑 on 2022/6/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FactoryMethodClient2 : NSObject

@end

@interface PersonFactoryMethodClient2 : FactoryMethodClient2

- (void)test;
@end


NS_ASSUME_NONNULL_END
